package com.example.cgpa

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Default 10-point scale. Every value can be edited in the Grades tab. */
val DEFAULT_GRADES: List<Pair<String, Double>> = listOf(
    "O" to 10.0, "A+" to 9.0, "A" to 8.0, "B+" to 7.0,
    "B" to 6.0, "C" to 5.0, "P" to 4.0, "F" to 0.0
)

/** grade = "" means the subject has not been graded yet and is left out of the maths. */
data class Course(val id: String, val name: String, val credits: Double, val grade: String)

data class Semester(val id: String, val name: String, val courses: List<Course>)

data class AppData(
    val grades: List<Pair<String, Double>> = DEFAULT_GRADES,
    val semesters: List<Semester> = emptyList(),
    val percentFactor: Double = 9.5
)

data class Result(val credits: Double, val points: Double) {
    val gpa: Double?
        get() = if (credits == 0.0) null else points / credits
}

fun AppData.pointsFor(grade: String): Double? = grades.firstOrNull { it.first == grade }?.second

/** SGPA maths: sum(credits x grade points) / sum(credits), over graded subjects only. */
fun AppData.resultOf(courses: List<Course>): Result {
    var c = 0.0
    var p = 0.0
    for (course in courses) {
        val gp = pointsFor(course.grade) ?: continue
        c += course.credits
        p += course.credits * gp
    }
    return Result(c, p)
}

/** CGPA maths: the same formula over every graded subject in every semester. */
fun AppData.overall(): Result {
    var c = 0.0
    var p = 0.0
    for (s in semesters) {
        val r = resultOf(s.courses)
        c += r.credits
        p += r.points
    }
    return Result(c, p)
}

fun AppData.updateSemester(id: String, change: (Semester) -> Semester): AppData =
    copy(semesters = semesters.map { if (it.id == id) change(it) else it })

fun fmt2(d: Double?): String = if (d == null) "--" else "%.2f".format(d)
fun fmt1(d: Double): String = "%.1f".format(d)
fun fmtCredits(d: Double): String = if (d % 1.0 == 0.0) d.toInt().toString() else d.toString()

object Store {
    private const val PREFS = "cgpa"
    private const val KEY = "data"

    fun load(ctx: Context): AppData {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return AppData()
        return try {
            val o = JSONObject(raw)
            val grades = mutableListOf<Pair<String, Double>>()
            val ga = o.optJSONArray("grades")
            if (ga != null) {
                for (i in 0 until ga.length()) {
                    val g = ga.getJSONObject(i)
                    grades.add(Pair(g.getString("g"), g.getDouble("p")))
                }
            }
            val semesters = mutableListOf<Semester>()
            val sa = o.optJSONArray("semesters") ?: JSONArray()
            for (i in 0 until sa.length()) {
                val so = sa.getJSONObject(i)
                val courses = mutableListOf<Course>()
                val ca = so.optJSONArray("courses") ?: JSONArray()
                for (j in 0 until ca.length()) {
                    val co = ca.getJSONObject(j)
                    courses.add(Course(co.getString("id"), co.getString("name"), co.getDouble("cr"), co.optString("g", "")))
                }
                semesters.add(Semester(so.getString("id"), so.getString("name"), courses))
            }
            AppData(
                if (grades.isEmpty()) DEFAULT_GRADES else grades,
                semesters,
                o.optDouble("pf", 9.5)
            )
        } catch (e: Exception) {
            AppData()
        }
    }

    fun save(ctx: Context, d: AppData) {
        val o = JSONObject()
        o.put("pf", d.percentFactor)
        val ga = JSONArray()
        for (g in d.grades) {
            ga.put(JSONObject().put("g", g.first).put("p", g.second))
        }
        o.put("grades", ga)
        val sa = JSONArray()
        for (s in d.semesters) {
            val ca = JSONArray()
            for (c in s.courses) {
                ca.put(JSONObject().put("id", c.id).put("name", c.name).put("cr", c.credits).put("g", c.grade))
            }
            sa.put(JSONObject().put("id", s.id).put("name", s.name).put("courses", ca))
        }
        o.put("semesters", sa)
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }
}
