package com.example.cgpa

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable
fun PlannerScreen(data: AppData, pad: PaddingValues) {
    var target by rememberSaveable { mutableStateOf("8.5") }
    var credits by rememberSaveable { mutableStateOf("22") }

    val o = data.overall()
    val t = target.toDoubleOrNull()
    val n = credits.toDoubleOrNull()
    val maxGp = data.grades.maxOfOrNull { it.second } ?: 10.0

    Column(
        modifier = Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Target planner", style = MaterialTheme.typography.titleMedium)
        Text(
            "Your current CGPA is ${fmt2(o.gpa)} over ${fmtCredits(o.credits)} credits.",
            style = MaterialTheme.typography.bodyMedium
        )

        OutlinedTextField(
            value = target,
            onValueChange = { target = it },
            label = { Text("Target CGPA") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = credits,
            onValueChange = { credits = it },
            label = { Text("Next semester credits") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )

        if (t != null && n != null && t > 0.0 && n > 0.0) {
            val required = (t * (o.credits + n) - o.points) / n
            val best = (o.points + n * maxGp) / (o.credits + n)
            val message = if (required > maxGp + 1e-9) {
                "Not reachable in one semester. Even the top grade in every subject gives a CGPA of ${fmt2(best)}."
            } else if (required <= 0.0) {
                "You are already above it. Any grades next semester keep you at or above ${fmt2(t)}."
            } else {
                "You need an SGPA of ${fmt2(required)} next semester to reach a CGPA of ${fmt2(t)}."
            }
            Card(Modifier.fillMaxWidth()) {
                Text(
                    message,
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.titleMedium
                )
            }

            Text("What different results would give", style = MaterialTheme.typography.labelMedium)
            for (s in listOf(6.0, 7.0, 8.0, 9.0, 10.0)) {
                if (s > maxGp) continue
                val cg = (o.points + n * s) / (o.credits + n)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Next SGPA ${fmt2(s)}")
                    Text("CGPA ${fmt2(cg)}", fontWeight = FontWeight.SemiBold)
                }
            }
        } else {
            Text(
                "Enter a target CGPA and the credits of the next semester.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
