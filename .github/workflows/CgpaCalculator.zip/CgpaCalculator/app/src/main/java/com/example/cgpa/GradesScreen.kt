package com.example.cgpa

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable
fun GradesScreen(data: AppData, onChange: (AppData) -> Unit, pad: PaddingValues) {
    var resetKey by remember { mutableIntStateOf(0) }
    var newLetter by remember { mutableStateOf("") }
    var newPoints by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var factorText by remember(resetKey) { mutableStateOf(data.percentFactor.toString()) }

    Column(
        modifier = Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Grade scale", style = MaterialTheme.typography.titleMedium)
        Text(
            "Change the points to match your college. Every SGPA and CGPA updates.",
            style = MaterialTheme.typography.bodyMedium
        )

        data.grades.forEachIndexed { index, g ->
            GradeRow(
                letter = g.first,
                points = g.second,
                resetKey = resetKey,
                onPoints = { p ->
                    onChange(data.copy(grades = data.grades.mapIndexed { i, old -> if (i == index) Pair(old.first, p) else old }))
                },
                onRemove = {
                    onChange(data.copy(grades = data.grades.filterIndexed { i, _ -> i != index }))
                }
            )
        }

        Text("Add a grade", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = newLetter,
                onValueChange = { newLetter = it.take(4) },
                label = { Text("Letter") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = newPoints,
                onValueChange = { newPoints = it },
                label = { Text("Points") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.weight(1f)
            )
        }
        Button(onClick = {
            val letter = newLetter.trim()
            val p = newPoints.toDoubleOrNull()
            if (letter.isEmpty()) {
                err = "Enter a grade letter."
            } else if (p == null || p < 0.0) {
                err = "Enter the points for this grade."
            } else if (data.grades.any { it.first.equals(letter, ignoreCase = true) }) {
                err = "That grade already exists."
            } else {
                err = ""
                onChange(data.copy(grades = data.grades + Pair(letter, p)))
                newLetter = ""
                newPoints = ""
            }
        }) { Text("Add grade") }
        if (err.isNotEmpty()) Text(err, color = MaterialTheme.colorScheme.error)

        Text("Percentage", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
            value = factorText,
            onValueChange = { v ->
                factorText = v
                val f = v.toDoubleOrNull()
                if (f != null && f > 0.0 && f <= 100.0) {
                    onChange(data.copy(percentFactor = f))
                }
            },
            label = { Text("Percentage = CGPA x") },
            supportingText = { Text("Many colleges use 9.5. Check your own rule.") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )

        TextButton(onClick = {
            onChange(data.copy(grades = DEFAULT_GRADES, percentFactor = 9.5))
            resetKey += 1
        }) { Text("Reset grade scale to default") }
    }
}

@Composable
private fun GradeRow(
    letter: String,
    points: Double,
    resetKey: Int,
    onPoints: (Double) -> Unit,
    onRemove: () -> Unit
) {
    var text by remember(letter, resetKey) { mutableStateOf(points.toString()) }
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(letter, modifier = Modifier.width(48.dp), fontWeight = FontWeight.SemiBold)
        OutlinedTextField(
            value = text,
            onValueChange = { v ->
                text = v
                val p = v.toDoubleOrNull()
                if (p != null && p >= 0.0) {
                    onPoints(p)
                }
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.weight(1f)
        )
        TextButton(onClick = onRemove) { Text("Remove", color = MaterialTheme.colorScheme.error) }
    }
}
