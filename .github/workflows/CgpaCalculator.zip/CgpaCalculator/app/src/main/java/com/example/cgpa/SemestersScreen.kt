package com.example.cgpa

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.util.UUID

@Composable
fun SemestersScreen(
    data: AppData,
    onChange: (AppData) -> Unit,
    pad: PaddingValues,
    openId: String?,
    setOpenId: (String?) -> Unit
) {
    val open = data.semesters.firstOrNull { it.id == openId }
    if (open != null) {
        SemesterDetail(data, open, onChange, pad) { setOpenId(null) }
    } else {
        SemesterList(data, onChange, pad, setOpenId)
    }
}

@Composable
private fun SemesterList(
    data: AppData,
    onChange: (AppData) -> Unit,
    pad: PaddingValues,
    setOpenId: (String?) -> Unit
) {
    var showAdd by remember { mutableStateOf(false) }
    val overall = data.overall()
    val cgpa = overall.gpa

    LazyColumn(
        modifier = Modifier.padding(pad),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(16.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text("Overall CGPA", style = MaterialTheme.typography.labelSmall)
                        Text(
                            fmt2(cgpa),
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            "${fmtCredits(overall.credits)} graded credits, ${data.semesters.size} semester(s)",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Percentage", style = MaterialTheme.typography.labelSmall)
                        Text(
                            if (cgpa == null) "--" else fmt1(cgpa * data.percentFactor) + "%",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text("CGPA x ${data.percentFactor}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        item {
            Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("Add semester") }
        }

        if (data.semesters.isEmpty()) {
            item {
                Text(
                    "No semesters yet. Add a semester, then add its subjects with credits and grades.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        items(data.semesters, key = { it.id }) { s ->
            val r = data.resultOf(s.courses)
            Card(Modifier.fillMaxWidth().clickable { setOpenId(s.id) }) {
                Row(
                    Modifier.padding(16.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(s.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${s.courses.size} subject(s), ${fmtCredits(r.credits)} credits",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("SGPA", style = MaterialTheme.typography.labelSmall)
                        Text(
                            fmt2(r.gpa),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }

    if (showAdd) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("New semester") },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    placeholder = { Text("Semester ${data.semesters.size + 1}") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val finalName = if (name.isBlank()) "Semester ${data.semesters.size + 1}" else name.trim()
                    val s = Semester(UUID.randomUUID().toString(), finalName, emptyList())
                    onChange(data.copy(semesters = data.semesters + s))
                    showAdd = false
                    setOpenId(s.id)
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SemesterDetail(
    data: AppData,
    sem: Semester,
    onChange: (AppData) -> Unit,
    pad: PaddingValues,
    onBack: () -> Unit
) {
    var showAdd by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val r = data.resultOf(sem.courses)

    LazyColumn(
        modifier = Modifier.padding(pad),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onBack) { Text("Back to semesters") }
                Card(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(sem.name, style = MaterialTheme.typography.titleLarge)
                            Text("${fmtCredits(r.credits)} graded credits", style = MaterialTheme.typography.bodySmall)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("SGPA", style = MaterialTheme.typography.labelSmall)
                            Text(
                                fmt2(r.gpa),
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }

        if (sem.courses.isEmpty()) {
            item {
                Text("No subjects yet. Add the first one below.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        items(sem.courses, key = { it.id }) { c ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(c.name, style = MaterialTheme.typography.titleMedium)
                        Text("${fmtCredits(c.credits)} credit(s)", style = MaterialTheme.typography.bodySmall)
                    }
                    GradePicker(data.grades, c.grade) { g ->
                        onChange(data.updateSemester(sem.id) { s ->
                            s.copy(courses = s.courses.map { if (it.id == c.id) it.copy(grade = g) else it })
                        })
                    }
                    TextButton(onClick = {
                        onChange(data.updateSemester(sem.id) { s ->
                            s.copy(courses = s.courses.filter { it.id != c.id })
                        })
                    }) { Text("Remove", color = MaterialTheme.colorScheme.error) }
                }
            }
        }

        item {
            Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("Add subject") }
        }

        item {
            TextButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Delete semester", color = MaterialTheme.colorScheme.error)
            }
        }
    }

    if (showAdd) {
        AddCourseDialog(
            grades = data.grades,
            onDismiss = { showAdd = false },
            onAdd = { name, credits, grade ->
                val course = Course(UUID.randomUUID().toString(), name, credits, grade)
                onChange(data.updateSemester(sem.id) { s -> s.copy(courses = s.courses + course) })
                showAdd = false
            }
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete ${sem.name}?") },
            text = { Text("All its subjects will be removed and your CGPA will update.") },
            confirmButton = {
                TextButton(onClick = {
                    onChange(data.copy(semesters = data.semesters.filter { it.id != sem.id }))
                    confirmDelete = false
                    onBack()
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun GradePicker(grades: List<Pair<String, Double>>, current: String, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }) {
            Text(if (current.isEmpty()) "Grade" else current)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text("Not graded yet") },
                onClick = { onPick(""); open = false }
            )
            for (g in grades) {
                DropdownMenuItem(
                    text = { Text("${g.first}  (${g.second})") },
                    onClick = { onPick(g.first); open = false }
                )
            }
        }
    }
}

@Composable
private fun AddCourseDialog(
    grades: List<Pair<String, Double>>,
    onDismiss: () -> Unit,
    onAdd: (String, Double, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var credits by remember { mutableStateOf("") }
    var grade by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New subject") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Subject name") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = credits,
                    onValueChange = { credits = it },
                    label = { Text("Credits") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Grade")
                    GradePicker(grades, grade) { grade = it }
                }
                if (err.isNotEmpty()) Text(err, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val cr = credits.toDoubleOrNull()
                if (name.isBlank()) {
                    err = "Enter a subject name."
                } else if (cr == null || cr <= 0.0) {
                    err = "Enter credits greater than 0."
                } else {
                    onAdd(name.trim(), cr, grade)
                }
            }) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
